/* sudo sysctl -w kernel.randomize_va_space=0 then ... */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>

unsigned int secret = 0x1234;

void handle_fail(char *buf) {
  char msg[100];
  snprintf(msg, sizeof(msg), "Inval Passwd! %s\n", buf);
  printf(msg);
}

int main(int argc, char *argv[])
{
  
  int tmp = secret;

  char buf[100];
  printf("Password:");
  strncpy(buf,argv[1],99);

  if (!strcmp(buf, "263582\n")) {
    printf("Pass OK :)\n");
  } else {
    handle_fail(buf);
  }

  if (tmp != secret) {
    puts("Secret modified!\n");
    exit(1);
  }
  
  return 0;
}

