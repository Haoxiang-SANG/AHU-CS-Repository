/* sudo sysctl -w kernel.randomize_va_space=2 then ... */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char* p;
void func(int key)
{
    long i=0x12345678;


    char buf[32];
    printf("overflow me : ");
    sprintf(buf,"%s",p);
    
    if(i != 0x12345678) {
        printf(" Warnning: Buffer Overflow !!! \n");
     kill(0,11);
    }


    if(key == 0xcafebabe){
      setuid(0);
	    system("/bin/sh");
    }
    else{
        printf("Nah..\n");
    }
}
int main(int argc, char* argv[])
{
	  p=argv[1];
    func(0xdeadbeef);
    return 0;
}


